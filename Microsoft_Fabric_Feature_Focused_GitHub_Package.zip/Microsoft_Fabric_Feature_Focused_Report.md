# Microsoft Fabric: Orchestration, Scheduling, Monitoring, and Alerting

**Feature-focused technical report with targeted comparisons to Azure and AWS**  
**Research context:** November 2026  
**Scope:** Microsoft Fabric is the primary subject. Azure and AWS products appear only as side-by-side capability benchmarks, migration references, or justified extensions to Fabric.  
**Sources:** Inline citation numbers refer to the full official documentation URLs in the **References** section at the end.  
**Rendering:** Standard GitHub-flavored Markdown tables and local SVG diagrams; upload the Markdown and `diagrams/` folder together.

## Executive Summary

Microsoft Fabric combines Data Factory Pipelines, Dataflow Gen2, Notebook/Spark execution, Warehouse, OneLake, Real-Time Intelligence, and Power BI within a managed SaaS analytics platform. For the operational questions in this report, the practical Fabric stack is **Pipeline for workflow dependencies, Job Scheduler and event triggers for initiation, Monitoring hub for run inspection, Workspace Monitoring/Eventhouse for queryable telemetry, Capacity Metrics App for CU consumption, and Activator for alerts and actions**. These are related components, not one universal scheduler or monitoring engine. [1][2][5][6][10]

**Fabric's main advantage is integration across data and analytics workloads.** Compared with Azure Data Factory plus Azure Monitor, it requires fewer separately provisioned platform services for a Fabric-centric workload. Compared with AWS Glue plus Step Functions/EventBridge/CloudWatch, it is more tightly bound to the Fabric analytics estate. The principal trade-offs are incomplete ADF-style tumbling-window backfill, fewer generic state-machine semantics than Step Functions, and parts of workspace-level observability/alerting that remain in preview. [2][3][4][23][37]

**Recommended Fabric-first production baseline:** Use pipelines to orchestrate transformations and copies; schedule through Fabric Job Scheduler or trigger them from events; centralize eligible logs with Workspace Monitoring and KQL; define actionable rules in Activator; and manage contention with the Capacity Metrics App. Add Azure Monitor, Logic Apps, or the enterprise incident platform only where requirements such as dynamic thresholds, paging/escalation, extended retention, or ITSM integration justify the extra infrastructure. [2][10][11][14][27][29]

### Fabric Feature Summary and Direct Product Equivalents

| Fabric capability | Primary Fabric component | Azure comparison | AWS comparison | What matters for Fabric |
| --- | --- | --- | --- | --- |
| Data workflow orchestration | Data Factory Pipeline, Invoke Pipeline | ADF/Synapse Pipeline | Glue Workflow; Step Functions | Fabric specializes in data/analytics workflows, not general state-machine orchestration |
| Scheduled runs | Job Scheduler, Pipeline schedules | ADF Schedule/Tumbling Window triggers | EventBridge Scheduler, Glue triggers | Interval scheduling is not full ADF tumbling-window backfill |
| Event-triggered execution | Real-Time Hub, Eventstream, Activator, Pipeline event triggers | ADF event trigger, Event Grid | EventBridge rules | Event types and route complexity should determine the trigger path |
| Job run inspection | Monitoring hub | ADF Monitor | Glue console, Step Functions executions | Native job-level troubleshooting |
| Cross-workload operational telemetry | Workspace Monitoring → Eventhouse/KQL | Azure Monitor + Log Analytics | CloudWatch Logs/Metrics | Fabric monitoring uses queryable KQL data; feature maturity varies |
| Notifications/actions | Scheduled-failure email, Activator | Azure Monitor Alerts/Action Groups | CloudWatch Alarms/SNS/EventBridge | Higher-end escalation and anomaly detection may need an external system |
| Capacity and cost | Fabric Capacity Metrics App, CU model | ADF activity/DIU + Azure Monitor usage | Glue DPU, Step Functions transitions, CloudWatch | Fabric requires shared-capacity contention analysis |
| Deployment | Git integration, Deployment pipelines, REST/CLI, Terraform | ADF Git/ARM/Bicep | CDK/CloudFormation/Terraform | Fabric items and schedules can participate in CI/CD |

The mappings above are functional comparisons, not product-equivalence claims. One Fabric component may span several other-cloud functions, while some Azure or AWS service features have no native Fabric counterpart. [1][4][17][22][35][37]

## 1. Microsoft Fabric Operational Architecture

Fabric is a unified SaaS analytics platform in which Data Factory, Data Engineering, Data Science, Real-Time Intelligence, Data Warehouse, Databases, and Power BI use OneLake and shared platform services. OneLake acts as a unified logical data lake, enabling different analytical engines to access the same underlying data without requiring a separate copy between every service. [1]

![Microsoft Fabric architecture](diagrams/01_microsoft_fabric_architecture.svg)

Pipelines can execute on demand, by a time-based schedule, or in response to events. Event-driven initiation may consume OneLake, Azure Blob, or Fabric job events and connect to Real-Time Hub, Eventstream, and Activator capabilities. Notebooks and Spark Job Definitions can also be scheduled through the shared Job Scheduler. [5][6][20][21]

A Fabric “workflow” is not one single DAG engine; it consists of several layers. Pipelines define activity dependencies and control flow; Invoke Pipeline composes pipelines; Job Scheduler provides recurring execution for individual items; and Real-Time Hub/Activator handles event-driven automation. Common control-flow activities include ForEach, If, Fail, Notebook, Dataflow, Stored Procedure, and Invoke Pipeline. [6][7][8]

The architecture figure is intentionally **Fabric-only**. Azure and AWS serve as reference points in the specific capability sections that follow, rather than as separate platform tutorials. A Fabric workflow commonly uses Pipeline activities to invoke a Dataflow Gen2, Notebook, Copy, or Warehouse operation; OneLake provides shared data access, while monitoring and incident response occur through additional Fabric operational surfaces. [1][7][10]

### Responsibilities of the Core Fabric Components

| Fabric component | Role in a production workflow | Operational distinction |
| --- | --- | --- |
| Data Factory Pipeline | Dependencies, branching, loops, calls to transformation/copy workloads | Primary orchestration canvas, not a universal enterprise state machine |
| Invoke Pipeline activity | Child pipelines, modular composition, cross-workspace invocation | Reuse and migration between pipeline boundaries |
| Dataflow Gen2 | Low-code Power Query transformations | Execution is monitored as a data workload, and consumes capacity |
| Notebook / Spark Job Definition | Programmable transformation, compute-heavy engineering and ML | Spark run/compute characteristics differ from pipeline activity overhead |
| Job Scheduler | Recurring time-based runs of supported Fabric items | Schedule management and job submission, separate from the pipeline DAG |
| Real-Time Hub / Eventstream | Discover, route, and transform supported events | Event ingestion and routing, not a replacement for all batch orchestration |
| Activator | Evaluate event or query-derived conditions and trigger actions | Event-driven response and alerts |
| Monitoring hub | Inspect runs and execution status | Operational troubleshooting UI |
| Workspace Monitoring / Eventhouse | Persist supported item telemetry and query with KQL | Cross-item investigation, trend reporting, alert rule inputs |
| Capacity Metrics App | Observe CU consumption, background work, and throttling | Shared resource management and workload isolation decisions |

## 2. Orchestration in Microsoft Fabric

### 2.1 Supported Fabric Workloads and Their Direct Equivalents

| Capability | Microsoft Fabric | Azure | AWS |
| --- | --- | --- | --- |
| ETL/ELT | Pipeline, Dataflow Gen2, Copy Job | ADF/Synapse Pipeline, Mapping Data Flow | Glue ETL |
| Batch computation | Pipeline, Notebook, Spark Job | ADF, Synapse Spark, Databricks, etc. | Glue, EMR, Batch |
| Streaming | Real-Time Hub, Eventstream, Eventhouse | Event Hubs, Stream Analytics, Synapse | Kinesis, MSK, Glue streaming |
| ML | Notebook/Data Science, callable through pipelines | Azure ML, Databricks, Synapse Spark | SageMaker, Glue, Step Functions |
| SQL/warehouse | Fabric Warehouse, SQL DB, SQL endpoint | Synapse SQL, Azure SQL | Redshift, Athena, RDS |
| Generic workflows | Moderate: primarily data pipelines | Moderate: ADF/Synapse primarily data-oriented | Strong: native Step Functions state machines |
| Event orchestration | Real-Time Hub + Activator | Event Grid + Logic Apps/ADF | EventBridge + Step Functions |

Fabric exposes the listed workloads as integrated experiences; the Azure and AWS entries are included only as functional equivalents, not as recommended full-stack replacements. The key boundary is that Fabric Pipelines primarily orchestrate data workloads, whereas AWS Step Functions is a general cross-service state machine and ADF emphasizes data integration. [1][35][37]

### 2.2 Activity Dependencies, Retries, and SLA Semantics

Fabric Pipeline dependencies are represented by activity connections and control flow. Most activities support timeout and configurable automatic retry. The published Pipeline resource limit lists a maximum pipeline activity-run timeout of 24 hours. Retry count and fixed or increasing-delay intervals can be configured per supported activity. Conditional retry capabilities are documented in preview. Pipeline-level resource limits include a maximum of 120 activities per pipeline. [4][7][9]

**Fabric versus ADF/Synapse:** ADF Tumbling Window triggers have persisted window state, historical backfill, dependencies, trigger retry, and concurrency controls. Fabric interval schedules only partially reproduce this; time-slice backfill requires custom logic or external orchestration. This matters to hourly ingestion and regulated financial close workflows. [4][23]

**Fabric versus AWS Step Functions:** Fabric activities provide retry and conditional branches for data-oriented flows; Step Functions exposes explicit Retry/Catch policies, error categories, timeouts, and state-machine semantics for broader application workflows. For non-idempotent external operations, use idempotency keys or compensation in either design. [9][38]

**Fabric SLA implication:** Use Workspace Monitoring event timestamps and custom KQL to detect runs that exceed expected duration or approach a data freshness SLA. ADF has an elapsed-time metric that can support a more direct early-warning alert, while Fabric generally needs the derived query and Activator rule. [12][25][27]

**Design implication:** Use Fabric pipelines to coordinate data movement and transformations, separate reusable child pipelines with Invoke Pipeline, and reserve an external workflow service for workflows requiring long-lived callbacks, extensive non-Fabric API integrations, or specialized compensation semantics. [8][9][37][38]

## 3. Scheduling and Event-Driven Initiation in Fabric

### 3.1 Native Fabric Scheduling

Fabric has **on-demand pipeline runs**, **fixed/interval-based pipeline schedules**, and **Job Scheduler recurrence** for supported items. Job Scheduler supports minute-, hour-, day-, week-, and month-based recurrence, plus specified calendar dates/weekday patterns. Schedules can be deployed with item definitions and managed through APIs; per-item job-concurrency limits and automatic disabling after repeated failures require production checks. [5][6]

For pipelines, fixed and interval schedules are not operationally identical. The pipeline UI documentation states that interval schedules cannot be edited, enabled, or disabled in place; changing one requires deletion and recreation. Scheduled-run email notifications are distinct from alerts on on-demand jobs. [5]

### 3.2 Event-Driven Fabric Triggers

Fabric Pipelines can run from supported OneLake/Blob file events, Fabric job events, and workspace event patterns. Real-Time Hub and Eventstream provide event discovery/routing, and Activator evaluates conditions and can initiate actions. The exact supported source, filtering, and alert-action combination should be verified for the workspace and region. [5][20][21]

### 3.3 Recommended Fabric Scheduling Patterns

For hourly and daily batch workloads in Fabric, the baseline pattern is **Job Scheduler → Pipeline → Child Pipeline/Notebook → Warehouse**, with telemetry recorded in Workspace Monitoring. Event-driven ingestion follows **Source Event → Eventstream/Real-Time Hub → Activator → Pipeline**. Fabric also supports file and job event triggers. [5][20]

![Recommended scheduling pattern](diagrams/04_scheduling_pattern.svg)

For workloads requiring automatic reprocessing of hourly windows that failed yesterday, ADF Tumbling Window triggers are a more natural fit than Fabric interval schedules. For business workflows spanning dozens of AWS services that require durable compensating actions, Step Functions is generally more suitable than Glue Workflow. [23][37]

### 3.4 Targeted Scheduling Comparison

| Scheduling requirement | Fabric choice and limitation | Azure / AWS comparison |
| --- | --- | --- |
| Daily or hourly analytics refresh | Job Scheduler or pipeline schedule | ADF Schedule trigger / EventBridge Scheduler offer similar time-based starts |
| Window-dependent reprocessing | Parameterize the time window and explicitly implement backlog/replay | ADF Tumbling Window natively maintains windows, dependencies, and backfill |
| File arrives in storage | Supported Fabric storage event trigger, often backed by event features | ADF event trigger / EventBridge event rule |
| Job-status-to-next-job automation | Fabric job events + Activator or Pipeline dependency | Step Functions can model broader state transitions and task-level semantics |
| Time zone and calendar reliability | Verify Fabric recurrence settings, daylight-saving time, invalid dates, and disabled schedules | EventBridge Scheduler also offers timezone-aware cron and retry configuration |

Fabric is the default if the workflow stays mostly inside Fabric; ADF tumbling windows are the stronger fit for automatic historical window recovery, and Step Functions is stronger for durable multi-service state machines. [4][5][6][23][37][48]

## 4. Monitoring and Observability in Microsoft Fabric

### 4.1 Native Monitoring Surfaces, Coverage, and Operational KPIs

Fabric provides four major operational surfaces: **Monitoring hub** for job execution inspection, **Workspace Monitoring** for cross-item telemetry, **Capacity Metrics App** for CU consumption and throttling, and **Activator** for actions triggered by job events or KQL-derived conditions. Newer Monitoring hub capabilities and Workspace Monitoring are documented as preview features, so production adoption should include an explicit feature-readiness assessment. [2][3][10]

Workspace Monitoring has a particularly important architecture. It writes supported Fabric item logs and metrics to a Monitoring Item backed by Eventhouse/KQL. Telemetry from multiple workspaces may be centralized into another Monitoring Item, subject to configuration and regional restrictions. Operators can then use KQL Querysets, Real-Time Dashboards, Power BI, and Activator for analysis and alerting. By default, data generated before monitoring was enabled is not backfilled, and the default monitoring-data retention is 30 days. [2][12]

Documented coverage includes pipeline activity logs, Dataflow Gen2, Copy Job, Warehouse query execution, mirrored databases, semantic models, job events, and Activator, although available event types and schemas differ by Fabric item. [2]

A practical Fabric baseline should track at least the following:

| Category | Recommended metric or alert rule |
| --- | --- |
| Pipeline health | `Failed runs > 0` in a five-minute window |
| Activity failure rate | Failed activities / all activities over 15 minutes > 5% |
| Execution duration | Duration > 1.5–2× the trailing 7-/30-day P95 |
| Data freshness | Time since last successful run exceeds the data SLA |
| Queuing | Number of queued runs rises continuously |
| Retries | Retry count per run materially exceeds baseline |
| Copy | Copy throughput drops or duration increases materially |
| Warehouse | Query duration/P95, failed queries, CPU/storage pressure |
| Spark | Session/job startup latency, failure rate, and runtime |
| Capacity | CU utilization, throttling, overage, and background smoothing peaks |
| Activator | Notification delivery failures or delayed alerts |

These are **recommended operating thresholds**, not universal built-in Fabric defaults. The specific fields and thresholds must be validated against available item telemetry and workload baselines. [2][12][14]

An illustrative KQL pattern for workspace-wide pipeline failure monitoring is:

```kusto
ItemJobEventLogs
| where JobType == "Pipeline"
| where JobStatus == "Failed"
| where Timestamp > ago(10m)
| summarize Failures=count() by WorkspaceName, ItemName
| where Failures > 0
```

> **Implementation note:** This illustrates the analytical pattern rather than guaranteeing that every named field is present with exactly this spelling in every telemetry schema. Validate the current table and columns in your Monitoring Item before using it in production.

### 4.2 Fabric Monitoring Architecture and Data Flow

![Fabric monitoring and alerting architecture](diagrams/06_fabric_monitoring_alerting.svg)

The Monitoring Item is useful because it turns supported system telemetry into a KQL-accessible operational dataset. The same telemetry can feed historical failure analysis, workload-duration baselines, capacity-aware diagnostics, real-time dashboards, and Activator rules. Monitoring collection is not retroactive; verify current supported tables, item event schemas, region placement, and retention policy before deploying rules. [2][11][12]

### 4.3 Focused Comparison: Fabric vs. Azure Monitor vs. CloudWatch

| Operational need | Fabric native path | Targeted Azure comparison | Targeted AWS comparison |
| --- | --- | --- | --- |
| Pipeline execution troubleshooting | Monitoring hub and item run detail | ADF Monitor | Glue job details / Step Functions execution history |
| Cross-run log analysis | Workspace Monitoring → Eventhouse/KQL | Azure Monitor + Log Analytics (`ADFPipelineRun`, etc.) | CloudWatch Logs and Glue/Step Functions metrics |
| Duration and SLA analysis | Derive duration/freshness with KQL | ADF elapsed-time metrics and Azure Monitor rules | CloudWatch metrics/alarms plus custom measurements |
| Anomaly detection | KQL/Activator and emerging Fabric intelligence | Azure Monitor dynamic thresholds | CloudWatch anomaly detection |
| Trace across many app services | Item/job-centric Fabric telemetry; extend externally as needed | Azure Monitor's broader app/service observability | Step Functions + X-Ray tracing |
| Long-term audit and retention | Configure monitoring retention; add security audit logs separately | Log Analytics retention and diagnostic exports | CloudWatch Logs / CloudTrail / archive design |

**Fabric-specific decision:** Workspace Monitoring is strong when operations center on OneLake, Pipeline, Warehouse, Spark, and Power BI. Azure Monitor's dynamic thresholds/Action Groups and CloudWatch Composite Alarms/X-Ray are relevant benchmarks when selecting an external enterprise operations layer; they do not require relocating the analytical workload away from Fabric. [2][25][26][27][28][29][39][40][41][42][43]

## 5. Fabric Alerting and Incident Response

### 5.1 Native Alerting Mechanisms

Microsoft also documents a Workspace Monitoring + KQL Queryset + Activator approach for workspace-wide pipeline failure alerts, reducing the need to maintain one rule per pipeline. [11]

Fabric's basic no-cost job-failure email capability applies to failures of scheduled jobs. Broader job states (such as Started and Succeeded), richer notifications, and automated actions can use Activator and may consume Fabric capacity. [3]

For scheduled pipeline failures, the built-in email feature is the simplest mechanism, but it does **not** cover on-demand pipeline runs. For broader event types and automated actions, use Activator on job events or on KQL query results; the proposed Workspace Monitoring + KQL Queryset + Activator pattern can cover multiple pipelines with fewer per-item rules. [3][5][11]

### 5.2 Alert Selection and Escalation Guidance

| Scenario in Fabric | Preferred first implementation | Extend beyond Fabric when... |
| --- | --- | --- |
| Single scheduled pipeline fails | Scheduled-job failure email | Pager rotation, acknowledgement, or on-call routing is required |
| Any pipeline fails within a workspace | Workspace Monitoring KQL + Activator | Enterprise incident correlation across non-Fabric resources is required |
| Data not refreshed by expected time | KQL freshness/watermark query + Activator | Strict operational SLA needs external durable escalation |
| Duration deviates from typical baseline | KQL percentile/duration evaluation | Auto-adapting dynamic thresholds are required; consider Azure Monitor |
| CU contention threatens jobs | Capacity Metrics App + diagnostic review | Capacity-health incidents require independent alert delivery |
| Workflow failure requires recovery | Pipeline activity retry and failure branch | Long-running state-machine compensation or cross-cloud remediation is needed |

Azure Monitor Action Groups offer email/SMS/voice/webhook/Logic Apps escalation and dynamic metric thresholds; AWS combines CloudWatch alarms, SNS and optionally EventBridge/Lambda, including composite alarms. These are **comparators or extensions for specific Fabric operational gaps**, not separate AWS or Azure reference architectures. [27][28][29][39][43]

### 5.3 Reliability of the Fabric Alert Path

Workspace Monitoring ingestion and KQL monitoring paths have different capacity-throttling behaviors from Activator- and Power BI-based alert consumption. A serious CU incident may therefore delay the notification channel you rely on to detect it. For production-critical workloads, consider placing centralized Monitoring Items on a more stable capacity and keeping at least one out-of-band infrastructure-health alarm. [2][14]

## 6. Fabric Production Engineering: Security, Scalability, Cost, and CI/CD

### 6.1 Fabric Security and Auditing

Fabric separates control-plane administration from data-plane authorization. Workspace and item permissions determine who may manage an item; OneLake data access controls govern access to data itself and may be refined at folder, table, schema, row, or column levels depending on the workload and security model. Fabric also integrates Microsoft Entra ID, Purview, sensitivity labels, and auditing capabilities. [1][19]

**Fabric comparison point:** Azure ADF/Synapse exposes separately managed Azure RBAC, managed identities, Key Vault, network controls, and Integration Runtime (including self-hosted connectivity). Fabric simplifies the SaaS control plane, but connectivity and identity requirements still need explicit validation. [24]

**Fabric comparison point:** AWS Glue/Step Functions use IAM, KMS, CloudTrail and (where relevant) Lake Formation for separation of concerns; Fabric instead centers workspace/item permissions, OneLake security, and Entra ID. Both approaches require separate examination of job telemetry and access-audit records. [19][41][44]

For strongly regulated environments, all three architectures should distinguish **data-access/security audit records** from **job-execution telemetry**. Pipeline run logs alone do not constitute a complete access audit trail.

### 6.2 Fabric Limits and Capacity Scaling

Fabric's documented Pipeline limits include up to **1,000 pipelines per workspace**, **10,000 concurrent pipeline runs**, **120 activities per pipeline**, **20 schedules per pipeline**, **50-way ForEach parallelism**, and **100 queued runs per pipeline**. Limits can change, and should be rechecked at deployment time. [4]

Job Scheduler also documents limits such as up to 100 active concurrent jobs per item; submissions beyond the limit may fail. A single job may run for up to 24 days. [6]

Fabric's main operational scaling risk is often not the scheduler but **competition for shared Capacity Units (CUs)**. An F64 capacity provides 64 CUs, corresponding to a theoretical baseline of **1,536 CU-hours per day**. The Capacity Metrics App should therefore drive sizing rather than estimating capacity solely from pipeline counts. [14][15]

**Comparison that affects Fabric sizing:** ADF consumption is generally billed per activity/execution resource rather than by a single shared analytics capacity; AWS Glue uses DPUs while Step Functions/EventBridge have serverless control planes. Unlike those combinations, Fabric pipelines, Spark, Warehouse, and monitoring workloads can contend for the same CU budget, making Capacity Metrics and peak demand essential inputs to sizing. [14][30][37][45]

### 6.3 Fabric Consumption Estimate and Cost Comparison

**Microsoft Fabric.** A published Fabric Pipeline orchestration consumption rate is **0.0056 CU-hours for each non-copy activity run**. Copy data movement is metered using execution time and an intelligent-optimization throughput basis, with a published example rate of **1.5 CU-hours per hour of the corresponding copy-throughput resource**. Actual costs depend on CU consumption and the region/capacity commercial arrangement. [13]

Assume 100 daily workloads, each containing 10 non-copy activities and one ten-minute copy operation. With an equivalent copy-throughput resource, the illustrative monthly estimate is:

```text
non-copy:
100 × 30 × 10 × 0.0056 = 168 CU-hours

copy:
100 × 30 × (10/60) × 1.5 ≈ 750 CU-hours

pipeline total ≈ 918 CU-hours/month
```

An illustrative incremental capacity-consumption valuation is therefore:

```text
918 × regional CU-hour unit price
```

This does **not** include compute consumed by Notebooks, Dataflow Gen2, Warehouse, or other items invoked by the pipelines. Those workloads also consume Fabric capacity. Use actual Capacity Metrics App data to validate an estimate against real executions. [13]

Microsoft advertises Fabric capacity reservation savings of roughly 41% compared with pay-as-you-go pricing in applicable scenarios. Spark has an optional Autoscale Billing model, and capacity overage introduces additional billing mechanics. Commercial terms and available configurations should be checked for the target region and date. [15][16]

**Only the Fabric estimate above is used for Fabric sizing.** The other-cloud numbers below help illustrate different meters, but they cannot be compared as equivalent workloads:

| Cost benchmark | Meter and original illustrative example | Why it matters when evaluating Fabric |
| --- | --- | --- |
| Fabric Pipelines | 0.0056 CU-hours per non-copy activity; example totals ~918 CU-hours/month including the hypothetical copy work | Data Factory consumption shares Fabric capacity with other analytical workloads |
| Azure Data Factory | Example 30,000 activity runs at ~$1/1,000 plus 2,000 DIU-hours at ~$0.25 = ~$530/month, excluding monitoring and downstream compute | Activity and Integration Runtime units are different from CU-hours |
| AWS Glue | Example 6 DPUs × 15 minutes × $0.44 × 30 = $19.80/month | DPU-based Spark execution is not a substitute for a Fabric pipeline-wide costing model |
| AWS Step Functions / EventBridge | Example 60,000 Standard transitions after 4,000 free ≈ $1.40; Scheduler free tier covers first 14M invocations | Orchestration charges may be small relative to compute, logs, storage, and downstream work |

These are illustrative vendor-pricing assumptions, not normalized quotes or comparative total-cost-of-ownership results. Actual regional pricing and service terms must be checked for a current deployment. [13][16][30][31][45][46][47]

### 6.4 Fabric CI/CD and Infrastructure as Code

Fabric's CI/CD capabilities include GitHub/Azure DevOps Git integration, Deployment pipelines, REST APIs, Variable Libraries, Fabric CLI, a Terraform provider, and `fabric-cicd`. Microsoft's guidance discusses Terraform for provisioning Fabric infrastructure as part of a CI/CD practice. [17][18]

Job Scheduler schedules can also take part in item deployment: they are represented in item definitions via `.schedules` files and can be managed by public APIs. [6]

A conceptual Fabric CI/CD lifecycle looks like this:

```yaml
# Conceptual example; not a complete Fabric CLI workflow.
pull_request:
  - validate item definitions
  - validate environment variables

merge_to_main:
  - sync workspace from Git
  - deploy Dev -> Test
  - run smoke pipelines
  - query Monitoring Item for failures
  - deploy Test -> Prod
```

Fabric providers and APIs continue to evolve. Terraform resource schemas should be validated against the official provider version in use rather than copied unchanged into long-lived templates. [17]

**Direct comparison only:** ADF/Synapse typically deploys pipelines using Git and ARM/Bicep with Azure DevOps/GitHub; AWS commonly uses CDK/CloudFormation/Terraform for Glue, Step Functions, and EventBridge. The important Fabric consideration is that its workspace item definitions, schedules, Git integration, Deployment pipelines, API/CLI, and Terraform must be treated as a coherent deployment unit, with environment-specific secrets and variables controlled separately. [6][17][18][32][33][48]

## 7. Fabric Failure Recovery and Migration Considerations

### 7.1 Failure Modes that Matter in Fabric

Fabric's most important operational failure modes include capacity throttling; contention with downstream Spark or Warehouse execution; expired or invalid pipeline authentication credentials; transient activity errors; automatic disabling of schedules; and the possibility that Monitoring/Activator itself is affected by capacity pressure. The Job Scheduler documentation describes automatically disabling schedules after repeated consecutive failures, with thresholds varying by item (often around ten failures). [6]

A further consideration is the dependence of Activator and Power BI monitoring experiences on the state of their underlying monitoring database and capacity. During serious capacity throttling, **the capacity producing the incident and the capacity supporting alert generation may interfere with one another**. Some monitoring ingestion and query paths may remain available while Activator-driven notifications are delayed or throttled. [2]

Accordingly, critical Fabric deployments should consider placing centralized Monitoring Items on a separate or more stable capacity rather than sharing all operational visibility with the most burst-prone production workloads.

Compared with Fabric capacity contention and item-level credentials, Azure ADF introduces Integration Runtime reachability and hybrid connectivity as more prominent operational failure sources; AWS Step Functions/Glue often expose downstream throttling, state-timeout, and IAM/event-delivery failure paths. Those comparisons matter mainly when designing migration or hybrid Fabric operations. [24][38]

### 7.2 Recovery Pattern for Fabric Pipelines

Use this fault-handling pattern for Fabric pipelines and the downstream services they invoke:

![Failure recovery pattern](diagrams/05_failure_recovery.svg)

The most important principle is that **retry must be paired with idempotency**. For operations with side effects, such as INSERT statements, payments, or external API calls, raising the retry count alone is insufficient; use transaction keys, checkpoints, or compensating workflows. Step Functions Standard's workflow-execution semantics help, but downstream services must still be designed for idempotency. [37]

### 7.3 Migrating from Azure Data Factory/Synapse into Fabric

The main challenge in migrating ADF to Fabric is not necessarily the Copy activity; it is the **scheduling and operational semantics**. Microsoft describes support for many familiar ADF copy and orchestration patterns, but tumbling windows are only partially matched, and native backfill is missing. Historical reprocessing and window dependency chains therefore need separate migration designs. [4]

| ADF/Synapse | Fabric equivalent or migration pattern |
| --- | --- |
| Pipeline | Fabric Pipeline |
| Execute Pipeline | Invoke Pipeline |
| Schedule Trigger | Job Scheduler / Pipeline Schedule |
| Storage Event Trigger | Fabric event trigger |
| Tumbling Window | Interval schedule + parameterized window; implement backfill separately |
| Mapping Data Flow | Dataflow Gen2 / Notebook / Spark |
| ADLS | OneLake / Shortcut |
| Azure Monitor logs | Workspace Monitoring / Eventhouse |
| Alert Rule | Activator / Scheduled job failure notification |
| ARM CI/CD | Git + Deployment Pipelines + Terraform/REST |

Fabric's Invoke Pipeline activity supports cross-workspace invocation and interoperability patterns with ADF/Synapse, providing an incremental migration bridge. [8]

### 7.4 Migrating Selected AWS Data Workloads into Fabric

An AWS Glue Job maps reasonably well to Fabric Notebook, Spark Job, or Dataflow Gen2. S3 objects may be copied into, or referenced through supported OneLake shortcuts from, Fabric. Glue Workflows and EventBridge schedules can be redesigned with Fabric Pipelines and Job Scheduler/Real-Time Hub.

The difficult migration cases are long-running Step Functions state machines with callback tokens, complex compensation, and orchestration across dozens of AWS service integrations. Fabric Pipelines are **not a drop-in equivalent to Step Functions state machines**. Step Functions Standard can run for up to one year, while Fabric is oriented more strongly toward analytical jobs and data pipelines. [37]

Therefore, do not rewrite every Step Functions business workflow as a Fabric pipeline merely to consolidate on one cloud data platform. Migrate the components that genuinely belong in the data-engineering and analytics control plane.

### 7.5 Integration with Existing Enterprise Observability

Fabric's common cross-platform integration approach is **Workspace Monitoring → Eventhouse/KQL → API/export/integration**, or connecting Fabric operational events with adjacent Azure infrastructure or an existing enterprise observability platform. The contrast is relevant: Azure Monitor can export diagnostics to Event Hubs and other destinations, and CloudWatch supports metric, log, and OpenTelemetry ecosystems. A centralized SIEM/APM estate should not rely solely on Fabric Monitoring hub screens. [2][25][26][49]

### 7.6 Implementation Priorities for Fabric

For Fabric production workloads, adopt a four-layer approach: **L1 job status; L2 workload performance; L3 capacity and SLA; and L4 incident response**. L1 uses Monitoring hub and scheduled-failure notifications; L2 uses Workspace Monitoring/KQL; L3 uses Capacity Metrics, freshness, and P95 duration; L4 uses Activator and Teams/email, extended to Logic Apps or ITSM/on-call platforms such as PagerDuty where appropriate. Fabric covers many elements of the first three layers, but organization-wide escalation policies, on-call rotations, dynamic anomaly detection, and mature incident management are often better handled with Azure Monitor or a specialized external system. [2][3][10][29]

## 8. Fabric Limitations and Final Recommendations

Fabric's most strategically important direction is not simply another Pipeline activity. It is the convergence of **Workspace Monitoring, Monitoring hub, Activator, Operations Agent, and unified CI/CD**. Microsoft's documentation positions Workspace Monitoring as a major operational observability entry point and describes Monitoring Items alongside Eventhouse, Activator, and emerging operational intelligence capabilities. Fabric is increasingly treating platform telemetry itself as a queryable data product. [2]

However, as of November 2026, several constraints should be treated as architectural concerns rather than minor feature gaps: Workspace Monitoring and certain job alert features are still in preview; each workspace can have only one active telemetry collection arrangement under the documented model; monitoring targets must satisfy regional requirements; retention defaults to 30 days; the monitoring database is read-only; Fabric Pipeline does not fully support tumbling-window backfill; pipelines have limits such as 120 activities and 20 schedules; and capacity contention can affect both business execution and portions of the alerting path. [2][3][4]

If the primary goal is a **unified lakehouse, Power BI, data engineering, real-time analytics, and operations experience**, Fabric generally introduces the least architectural assembly overhead. If the core requirement is **complex scheduling dependencies, hybrid networking, and strict SLA operations**, Azure Data Factory/Synapse plus Azure Monitor remains more mature. If the requirement is **high-throughput serverless event orchestration, durable long-running workflows, and state machines spanning many services**, AWS Step Functions plus EventBridge offers the stronger workflow abstraction. [1][23][27][37]

For most Microsoft-centric enterprises, the most practical target architecture is **not Fabric versus Azure as an exclusive choice**. Instead, it is **Fabric as the data-platform orchestration/control plane and Azure Monitor, Logic Apps, and enterprise ITSM as the cross-platform operations control plane**. This retains Fabric's unified management of OneLake, Pipeline, Warehouse, Spark, and Power BI while leveraging Azure Monitor's dynamic thresholds, Action Groups, longer-term diagnostics, and external incident-management integrations. [1][27][29]

### Recommended Adoption Decision

| Requirement | Fabric-first recommendation | When to compare or integrate another service |
| --- | --- | --- |
| Unified lakehouse/ETL/BI operations | **Use Fabric Pipeline + Job Scheduler + Workspace Monitoring + Activator** | External tools only for gaps or central incident policy |
| Cross-item failure visibility | Enable supported Workspace Monitoring telemetry, validate schema, create KQL alerts | Azure Monitor/third-party tool if multiple non-Fabric systems must be correlated |
| Batch window backfill | Parameterize windows and implement reprocessing explicitly | ADF Tumbling Window when native time-window recovery is essential |
| Durable application state machines | Keep Fabric focused on analytical workloads | AWS Step Functions or appropriate general workflow engine when callback/compensation semantics dominate |
| Dynamic anomaly detection, paging, ITSM | Use Fabric telemetry as the signal source | Azure Monitor/Logic Apps/on-call platform as incident delivery and governance layer |
| Capacity-constrained ETL | Measure CU consumption and queue/throttling before sizing | Compare fully normalized usage models; do not compare CU, DPU, and DIU prices directly |

**Bottom line:** The report's architecture and recommendations center on Microsoft Fabric. Azure and AWS are useful chiefly to establish the exact capabilities Fabric can replace, what it does differently, and which advanced scheduling or operational requirements still justify integration with a specialized external service. [1][2][4][23][27][37]

## References

All source URLs are consolidated here rather than embedded in the report body. References are grouped by platform and numbered to match the citations in the text. These are primarily official vendor documentation and pricing pages; preview status, limits, and pricing should be checked again at implementation time.

**Microsoft Fabric — architecture, pipelines, scheduling, observability, security, and pricing**

[1] Microsoft Learn — *What is Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/fundamentals/microsoft-fabric-overview

[2] Microsoft Learn — *Workspace Monitoring Overview*.  
https://learn.microsoft.com/en-us/fabric/fundamentals/workspace-monitoring-overview

[3] Microsoft Learn — *Set up job alerts in the Monitor hub (preview)*.  
https://learn.microsoft.com/en-us/fabric/admin/monitoring-hub-alerts

[4] Microsoft Learn — *Data Factory limitations overview*.  
https://learn.microsoft.com/en-us/fabric/data-factory/data-factory-limitations

[5] Microsoft Learn — *Run, schedule, or use events to trigger a pipeline*.  
https://learn.microsoft.com/en-us/fabric/data-factory/pipeline-runs

[6] Microsoft Learn — *Job Scheduler in Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/fundamentals/job-scheduler

[7] Microsoft Learn — *Activity overview*.  
https://learn.microsoft.com/en-us/fabric/data-factory/activity-overview

[8] Microsoft Learn — *Invoke pipeline activity*.  
https://learn.microsoft.com/en-us/fabric/data-factory/invoke-pipeline-activity

[9] Microsoft Learn — *Activity Retries in Microsoft Fabric Data Factory*.  
https://learn.microsoft.com/en-us/fabric/data-factory/activity-retries

[10] Microsoft Learn — *Choose How to Monitor Pipeline Runs*.  
https://learn.microsoft.com/en-us/fabric/data-factory/monitor-data-factory

[11] Microsoft Learn — *Create Alerts for Pipeline Runs*.  
https://learn.microsoft.com/en-us/fabric/data-factory/create-alerts-for-pipeline-runs

[12] Microsoft Learn — *Enable Workspace Monitoring (Preview) in Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/data-factory/workspace-monitoring

[13] Microsoft Learn — *Pricing for Pipelines*.  
https://learn.microsoft.com/en-us/fabric/data-factory/pricing-pipelines

[14] Microsoft Learn — *Plan your capacity size*.  
https://learn.microsoft.com/en-us/fabric/enterprise/plan-capacity

[15] Microsoft Learn — *Capacity overage in Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/enterprise/capacity-overage-overview

[16] Microsoft Azure — *Microsoft Fabric pricing*.  
https://azure.microsoft.com/en-us/pricing/details/microsoft-fabric/

[17] Microsoft Learn — *Introduction to CI/CD in Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/cicd/cicd-overview

[18] Microsoft Learn — *Plan CI/CD for Microsoft Fabric Solutions*.  
https://learn.microsoft.com/en-us/fabric/fundamentals/understand-best-practices-fabric-cicd

[19] Microsoft Learn — *Data security overview*.  
https://learn.microsoft.com/en-us/fabric/onelake/get-started-security

[20] Microsoft Learn — *Explore Job events in Fabric Real-Time hub*.  
https://learn.microsoft.com/en-us/fabric/real-time-hub/explore-fabric-job-events

[21] Microsoft Learn — *Run an Apache Spark job definition*.  
https://learn.microsoft.com/en-us/fabric/data-engineering/run-spark-job-definition

**Microsoft Azure — Data Factory, Azure Monitor, CI/CD, and pricing**

[22] Microsoft Learn — *Pipeline execution and triggers in ADF/Synapse*.  
https://learn.microsoft.com/en-us/azure/data-factory/concepts-pipeline-execution-triggers

[23] Microsoft Learn — *Create tumbling window triggers*.  
https://learn.microsoft.com/en-us/azure/data-factory/how-to-create-tumbling-window-trigger

[24] Microsoft Learn — *Integration Runtime in ADF/Synapse*.  
https://learn.microsoft.com/en-us/azure/data-factory/concepts-integration-runtime

[25] Microsoft Learn — *Monitor Azure Data Factory*.  
https://learn.microsoft.com/en-us/azure/data-factory/monitor-data-factory

[26] Microsoft Learn — *Configure diagnostic settings and a workspace*.  
https://learn.microsoft.com/en-us/azure/data-factory/monitor-configure-diagnostics

[27] Microsoft Learn — *Types of Azure Monitor alerts*.  
https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-types

[28] Microsoft Learn — *Dynamic thresholds for Azure Monitor alert rules*.  
https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-dynamic-thresholds

[29] Microsoft Learn — *Create and manage Action Groups in Azure Monitor*.  
https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/action-groups

[30] Microsoft Azure — *Azure Data Factory data pipeline pricing*.  
https://azure.microsoft.com/en-us/pricing/details/data-factory/data-pipeline/

[31] Microsoft Azure — *Azure Monitor pricing*.  
https://azure.microsoft.com/en-us/pricing/details/monitor/

[32] Microsoft Learn — *Automated publishing for ADF continuous integration and delivery*.  
https://learn.microsoft.com/en-us/azure/data-factory/continuous-integration-delivery-improvements

[33] Microsoft Learn — *Create monitoring resources using Bicep*.  
https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/scenarios-monitoring

[34] Microsoft Learn — *Operationalize data pipelines*.  
https://learn.microsoft.com/en-us/azure/data-factory/tutorial-operationalize-pipelines

**Amazon Web Services — Glue, Step Functions, EventBridge, CloudWatch, and pricing**

[35] AWS Documentation — *Overview of workflows in AWS Glue*.  
https://docs.aws.amazon.com/glue/latest/dg/workflows_overview.html

[36] AWS Documentation — *Automating AWS Glue with EventBridge*.  
https://docs.aws.amazon.com/glue/latest/dg/automating-awsglue-with-cloudwatch-events.html

[37] AWS Documentation — *Choosing workflow type in AWS Step Functions*.  
https://docs.aws.amazon.com/step-functions/latest/dg/choosing-workflow-type.html

[38] AWS Documentation — *Configure error handling in Step Functions*.  
https://docs.aws.amazon.com/step-functions/latest/dg/workflow-studio-process-error.html

[39] AWS Documentation — *Monitoring AWS Glue with Amazon CloudWatch*.  
https://docs.aws.amazon.com/glue/latest/dg/monitor-cloudwatch.html

[40] AWS Documentation — *Monitoring Step Functions metrics with CloudWatch*.  
https://docs.aws.amazon.com/step-functions/latest/dg/procedure-cw-metrics.html

[41] AWS Documentation — *Using CloudWatch Logs to log Step Functions execution history*.  
https://docs.aws.amazon.com/step-functions/latest/dg/cw-logs.html

[42] AWS Documentation — *Trace Step Functions with AWS X-Ray*.  
https://docs.aws.amazon.com/step-functions/latest/dg/concepts-xray-tracing.html

[43] AWS Documentation — *Composite alarms in Amazon CloudWatch*.  
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/alarm-combining.html

[44] AWS Documentation — *Logging and monitoring in AWS Glue*.  
https://docs.aws.amazon.com/glue/latest/dg/logging-and-monitoring.html

[45] AWS — *AWS Glue pricing*.  
https://aws.amazon.com/glue/pricing/

[46] AWS — *AWS Step Functions pricing*.  
https://aws.amazon.com/step-functions/pricing/

[47] AWS — *Amazon EventBridge pricing*.  
https://aws.amazon.com/eventbridge/pricing/

[48] AWS — *Amazon EventBridge FAQs*.  
https://aws.amazon.com/eventbridge/faqs/

[49] AWS Documentation — *Metrics in Amazon CloudWatch*.  
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/working_with_metrics.html
