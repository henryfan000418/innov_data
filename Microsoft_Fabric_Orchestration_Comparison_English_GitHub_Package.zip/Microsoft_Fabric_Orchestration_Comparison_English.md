# Microsoft Fabric Orchestration, Scheduling, Monitoring, and Alerting: An In-Depth Comparison with Azure and AWS

**Research context:** November 2026  
**Scope:** Microsoft Fabric, Azure-native data orchestration and operations services, and AWS-native workflow and observability services.  
**Citation convention:** Bracketed reference numbers point to full, clickable source URLs in the **References** section at the very end of this report. Architecture diagrams use Mermaid syntax, supported by GitHub Markdown.

## Executive Summary

By 2026, Microsoft Fabric has evolved significantly beyond a collection of analytics SaaS and data-engineering tools. It now offers unified orchestration, job scheduling, workspace-level observability, event-driven automation, and centralized CI/CD capabilities. Its core advantage is not that any one scheduler or alert engine is necessarily the most powerful; rather, **Data Factory, Notebook/Spark, Warehouse, Real-Time Intelligence, OneLake, Monitoring hub, Workspace Monitoring, Activator, and Power BI share a SaaS platform and capacity model**. This provides a more unified operational experience across ETL, SQL, Spark, streaming, and BI than the traditional Azure approach of composing multiple independent resources. An important qualification remains: some operational capabilities—including the newer Monitoring hub experiences, Workspace Monitoring, and certain Activator/job-alert capabilities—are still documented as preview features. Fabric interval scheduling also lacks the complete tumbling-window backfill semantics found in Azure Data Factory (ADF). [1][2][3][4]

The three approaches can be summarized as follows: **Fabric is the most unified, Azure offers the most granular operational configuration, and AWS is the most modular.** Fabric suits organizations that want less platform assembly, store much of their analytical data in OneLake, and rely heavily on Microsoft 365 and Power BI. Azure Data Factory/Synapse plus Azure Monitor and alerts suits organizations deeply invested in Azure that need hybrid connectivity, complex time windows, Log Analytics, dynamic thresholds, and mature enterprise alert governance. AWS Glue plus Step Functions, EventBridge, CloudWatch, and SNS fits environments emphasizing loosely coupled services, event-driven processing, scalable serverless workflows, and granular consumption-based billing. Azure Monitor's dynamic thresholds, Action Groups, and log-query alerts remain more mature as general-purpose monitoring tools than Fabric's native alert features. AWS Step Functions offers stronger explicit execution semantics, Retry/Catch, durable long-running workflows, and cross-service orchestration than a Fabric data pipeline. [27][28][29][37][38]

For a new Microsoft-centric data platform, the recommended baseline is **Fabric Pipeline/Job Scheduler for data workflow execution; Workspace Monitoring with Eventhouse/KQL as a telemetry layer; Activator for event-based alerts; and the Capacity Metrics App for capacity utilization and cost observability**. For strict SLAs, dynamic anomaly detection, SMS/voice escalation, or ITSM integration, extend Fabric telemetry and alerting into Azure Monitor, Logic Apps, or established third-party tooling. Teams migrating from ADF/Synapse should not mechanically map every ADF pipeline to one Fabric pipeline. Scheduling, transformation execution, and alerting responsibilities should first be reconsidered, because OneLake and the shared capacity model alter the architecture's boundaries. [2][10][17][18]

### Quick Decision Matrix

<table>
  <thead>
    <tr><th>Dimension</th><th>Microsoft Fabric</th><th>Azure-native combination</th><th>AWS-native combination</th></tr>
  </thead>
  <tbody>
    <tr><td>Best fit</td><td>Unified analytics/data/BI SaaS</td><td>Enterprise Azure data integration and monitoring</td><td>Modular, serverless workflow orchestration</td></tr>
    <tr><td>Orchestration core</td><td>Fabric Data Factory Pipelines</td><td>ADF / Synapse Pipelines</td><td>Step Functions + Glue Workflows</td></tr>
    <tr><td>Scheduling core</td><td>Fabric Job Scheduler / Pipeline schedules / event triggers</td><td>Schedule, Tumbling Window, and Event triggers</td><td>EventBridge Scheduler / Glue triggers</td></tr>
    <tr><td>Workspace-/platform-level monitoring</td><td>Monitoring hub + Workspace Monitoring</td><td>Azure Monitor + Log Analytics</td><td>CloudWatch</td></tr>
    <tr><td>Event-based alerting</td><td>Activator</td><td>Azure Monitor Alerts + Action Groups</td><td>CloudWatch Alarms + EventBridge + SNS</td></tr>
    <tr><td>Anomaly detection</td><td>Primarily KQL/Activator and emerging AI operations features</td><td>Mature Azure Monitor dynamic thresholds</td><td>CloudWatch anomaly detection / Glue data-quality anomaly features</td></tr>
    <tr><td>Workflow semantics</td><td>Pipeline control flow, data-engineering oriented</td><td>Pipeline control flow, mature time-window capabilities</td><td>Step Functions ASL, explicit Retry/Catch and execution semantics</td></tr>
    <tr><td>IaC / CI/CD</td><td>Git, Deployment pipelines, REST, Terraform</td><td>ARM/Bicep, Git, Azure DevOps/GitHub</td><td>CloudFormation/CDK/Terraform</td></tr>
    <tr><td>Primary cost model</td><td>Shared Fabric CU capacity</td><td>Activity, DIU, logs, and alerts charged separately</td><td>DPU, transitions, events, metrics, and logs charged separately</td></tr>
    <tr><td>Main risk</td><td>Parts of observability are still in preview</td><td>Many separately managed services and billing dimensions</td><td>More service components and potentially fragmented operations governance</td></tr>
  </tbody>
</table>
This comparison is based on official architecture, scheduler, monitoring, alerting, and pricing documentation from the three platforms. [1][22][35][37][39][46]

## Platform Architecture and Product Mapping

### Microsoft Fabric

Fabric is a unified SaaS analytics platform in which Data Factory, Data Engineering, Data Science, Real-Time Intelligence, Data Warehouse, Databases, and Power BI use OneLake and shared platform services. OneLake acts as a unified logical data lake, enabling different analytical engines to access the same underlying data without requiring a separate copy between every service. [1]

![Microsoft Fabric architecture](diagrams/01_microsoft_fabric_architecture.svg)

Pipelines can execute on demand, by a time-based schedule, or in response to events. Event-driven initiation may consume OneLake, Azure Blob, or Fabric job events and connect to Real-Time Hub, Eventstream, and Activator capabilities. Notebooks and Spark Job Definitions can also be scheduled through the shared Job Scheduler. [5][6][20][21]

A Fabric “workflow” is not one single DAG engine; it consists of several layers. Pipelines define activity dependencies and control flow; Invoke Pipeline composes pipelines; Job Scheduler provides recurring execution for individual items; and Real-Time Hub/Activator handles event-driven automation. Common control-flow activities include ForEach, If, Fail, Notebook, Dataflow, Stored Procedure, and Invoke Pipeline. [6][7][8]

### Equivalent Azure Architecture

Azure's equivalent is a **composed architecture rather than a single product**. ADF/Synapse Pipelines handle data orchestration, Integration Runtime performs data movement and execution, Azure Monitor/Log Analytics stores and analyzes metrics and logs, Azure Monitor Alerts evaluates alert conditions, and Action Groups deliver notifications or invoke automated remediation. [24][25][29]

![Azure orchestration and monitoring architecture](diagrams/02_azure_architecture.svg)

ADF/Synapse maintains a significant advantage for sophisticated batch scheduling, particularly **Tumbling Window triggers**. A tumbling window trigger is stateful and supports historical backfill, trigger dependencies, maximum concurrency, and trigger-level retry. An ordinary Schedule trigger is simpler and more lightweight. [22][23]

### Equivalent AWS Architecture

AWS has no single SaaS service fully equivalent to Fabric. A typical design assigns ETL to Glue; generic workflow state machines to Step Functions; schedules and events to EventBridge; metrics, logs, and alarms to CloudWatch; and notifications or remediation to SNS, Lambda, Systems Manager, and related services. Glue Workflow can also connect its own jobs, crawlers, and triggers. [35][36][37]

![AWS orchestration and monitoring architecture](diagrams/03_aws_architecture.svg)

Step Functions **Standard Workflows** support durable, auditable processes that can run for up to one year and have exactly-once workflow *execution* semantics. **Express Workflows** prioritize high throughput and run for up to five minutes, with different execution semantics and billing. Exactly-once workflow execution does not automatically make all downstream side effects exactly once; downstream actions still need appropriate idempotency controls. [37]

## Comparison of Orchestration, Scheduling, and Workload Capabilities

### Supported Workloads

<table>
  <thead>
    <tr><th>Capability</th><th>Microsoft Fabric</th><th>Azure</th><th>AWS</th></tr>
  </thead>
  <tbody>
    <tr><td>ETL/ELT</td><td>Pipeline, Dataflow Gen2, Copy Job</td><td>ADF/Synapse Pipeline, Mapping Data Flow</td><td>Glue ETL</td></tr>
    <tr><td>Batch computation</td><td>Pipeline, Notebook, Spark Job</td><td>ADF, Synapse Spark, Databricks, etc.</td><td>Glue, EMR, Batch</td></tr>
    <tr><td>Streaming</td><td>Real-Time Hub, Eventstream, Eventhouse</td><td>Event Hubs, Stream Analytics, Synapse</td><td>Kinesis, MSK, Glue streaming</td></tr>
    <tr><td>ML</td><td>Notebook/Data Science, callable through pipelines</td><td>Azure ML, Databricks, Synapse Spark</td><td>SageMaker, Glue, Step Functions</td></tr>
    <tr><td>SQL/warehouse</td><td>Fabric Warehouse, SQL DB, SQL endpoint</td><td>Synapse SQL, Azure SQL</td><td>Redshift, Athena, RDS</td></tr>
    <tr><td>Generic workflows</td><td>Moderate: primarily data pipelines</td><td>Moderate: ADF/Synapse primarily data-oriented</td><td>Strong: native Step Functions state machines</td></tr>
    <tr><td>Event orchestration</td><td>Real-Time Hub + Activator</td><td>Event Grid + Logic Apps/ADF</td><td>EventBridge + Step Functions</td></tr>
  </tbody>
</table>
Fabric explicitly presents Data Factory, Data Engineering, Data Science, Real-Time Intelligence, Warehouse, and Databases as integrated workload experiences. AWS separates data-focused Glue Workflows from cross-service Step Functions state machines. [1][35][37]

### Workflow Dependencies, Retries, and SLAs

Fabric Pipeline dependencies are represented by activity connections and control flow. Most activities support timeout and automatic retry. The documented default activity timeout is 12 hours, with a maximum of seven days, and retry count/interval can be configured. Conditional retry capabilities are documented in preview. Pipeline-level resource limits include a maximum of 120 activities per pipeline. [4][7][9]

ADF/Synapse excels in **time-window semantics**. A Tumbling Window trigger saves window state, backfills historical windows, and can declare dependencies on other tumbling windows. Trigger retry and concurrency are also part of the trigger definition. This makes it particularly well suited to financial daily close processes, hourly ingestion, and SLA-dependent batch chains. Fabric's interval-based scheduling partially approximates tumbling windows but, according to its documented limitations, does not provide the same built-in backfill mechanism. [4][23]

AWS Step Functions has a particularly explicit error-handling model. Retry behavior can be configured by error class, interval, maximum attempts, and backoff rate; Catch paths route failures to fallback states. Timeouts are also supported to prevent tasks from running indefinitely. [38]

For SLA management, Azure Data Factory exposes the `PipelineElapsedTimeRuns` metric for monitoring pipelines that run longer than expected. Together with Azure Monitor Alerts, this can produce an “at risk of missing SLA” notification before an actual failure. Fabric can express comparable logic with Workspace Monitoring timestamps and custom KQL, but this is less direct than ADF's pipeline elapsed-time metric. [12][30]

### Recommended Scheduling Patterns

For hourly and daily batch workloads in Fabric, the baseline pattern is **Job Scheduler → Pipeline → Child Pipeline/Notebook → Warehouse**, with telemetry recorded in Workspace Monitoring. Event-driven ingestion follows **Source Event → Eventstream/Real-Time Hub → Activator → Pipeline**. Fabric also supports file and job event triggers. [5][20]

![Recommended scheduling pattern](diagrams/04_scheduling_pattern.svg)

For workloads requiring automatic reprocessing of hourly windows that failed yesterday, ADF Tumbling Window triggers are a more natural fit than Fabric interval schedules. For business workflows spanning dozens of AWS services that require durable compensating actions, Step Functions is generally more suitable than Glue Workflow. [23][37]

## Monitoring, Alerting, and Observability

### Microsoft Fabric

Fabric provides four major operational surfaces: **Monitoring hub** for job execution inspection, **Workspace Monitoring** for cross-item telemetry, **Capacity Metrics App** for CU consumption and throttling, and **Activator** for actions triggered by job events or KQL-derived conditions. Newer Monitoring hub capabilities and Workspace Monitoring are documented as preview features, so production adoption should include an explicit feature-readiness assessment. [2][3][10]

Workspace Monitoring has a particularly important architecture. It writes supported Fabric item logs and metrics to a Monitoring Item backed by Eventhouse/KQL. Telemetry from multiple workspaces may be centralized into another Monitoring Item, subject to configuration and regional restrictions. Operators can then use KQL Querysets, Real-Time Dashboards, Power BI, and Activator for analysis and alerting. By default, data generated before monitoring was enabled is not backfilled, and the default monitoring-data retention is 30 days. [2][12]

Documented coverage includes pipeline activity logs, Dataflow Gen2, Copy Job, Warehouse query execution, mirrored databases, semantic models, job events, and Activator, although available event types and schemas differ by Fabric item. [2]

A practical Fabric baseline should track at least the following:

<table>
  <thead>
    <tr><th>Category</th><th>Recommended metric or alert rule</th></tr>
  </thead>
  <tbody>
    <tr><td>Pipeline health</td><td><code>Failed runs &gt; 0</code> in a five-minute window</td></tr>
    <tr><td>Activity failure rate</td><td>Failed activities / all activities over 15 minutes &gt; 5%</td></tr>
    <tr><td>Execution duration</td><td>Duration &gt; 1.5–2× the trailing 7-/30-day P95</td></tr>
    <tr><td>Data freshness</td><td>Time since last successful run exceeds the data SLA</td></tr>
    <tr><td>Queuing</td><td>Number of queued runs rises continuously</td></tr>
    <tr><td>Retries</td><td>Retry count per run materially exceeds baseline</td></tr>
    <tr><td>Copy</td><td>Copy throughput drops or duration increases materially</td></tr>
    <tr><td>Warehouse</td><td>Query duration/P95, failed queries, CPU/storage pressure</td></tr>
    <tr><td>Spark</td><td>Session/job startup latency, failure rate, and runtime</td></tr>
    <tr><td>Capacity</td><td>CU utilization, throttling, overage, and background smoothing peaks</td></tr>
    <tr><td>Activator</td><td>Notification delivery failures or delayed alerts</td></tr>
  </tbody>
</table>
These are **recommended operating thresholds**, not universal built-in Fabric defaults. The specific fields and thresholds must be validated against available item telemetry and workload baselines. [2][12][14]

An illustrative KQL pattern for workspace-wide pipeline failure monitoring is:

```kusto
ItemJobEventLogs
| where JobType == "Pipeline"
| where JobStatus == "Failed"
| where Timestamp > ago(10m)
| summarize Failures=count() by WorkspaceName, ItemName
| where Failures > 0
```

> **Implementation note:** This illustrates the analytical pattern rather than guaranteeing that every named field is present with exactly this spelling in every telemetry schema. Validate the current table and columns in your Monitoring Item before using it in production.

Microsoft also documents a Workspace Monitoring + KQL Queryset + Activator approach for workspace-wide pipeline failure alerts, reducing the need to maintain one rule per pipeline. [11]

Fabric's basic no-cost job-failure email capability applies to failures of scheduled jobs. Broader job states (such as Started and Succeeded), richer notifications, and automated actions can use Activator and may consume Fabric capacity. [3]

### Azure Monitor and Alerts

Azure Monitor provides one of the more comprehensive general-purpose observability control planes of the compared platforms. Metrics are stored in Azure Monitor's metrics store, while logs flow into Log Analytics. ADF diagnostic settings can export resource-specific run tables such as `ADFActivityRun`, `ADFPipelineRun`, and `ADFTriggerRun`. ADF's built-in run history is retained for a limited period (documented as 45 days); exporting diagnostics is needed for longer-term retention and cross-resource queries. [25][26]

Azure Monitor Alerts supports metric alerts, log-search alerts, activity-log alerts, smart detection, and Prometheus alerts. Metric alerts can use multiple conditions and dimensions, stateful/stateless behavior, and machine-learning-based dynamic thresholds. Action Groups can send email, SMS, voice, and push notifications, or invoke webhooks, Azure Functions, and Logic Apps. [27][29]

Dynamic thresholds learn from historical patterns, including seasonality and trends. Microsoft's documentation indicates that alerting begins after a minimum of roughly three days and 30 samples, while identifying weekly seasonality requires around three weeks of history. [28]

Therefore, for cases such as a sharp rise in execution duration or seasonal drops in throughput, Azure Monitor's built-in dynamic-threshold functions are more mature than the predominantly KQL/Activator-based patterns native to Fabric.

### AWS CloudWatch, EventBridge, and X-Ray

AWS Glue sends foundational metrics to CloudWatch and can provide continuous logging and Glue Observability metrics. Step Functions emits execution, activity, and service-integration metrics to CloudWatch. [39][40]

Step Functions **Standard** retains execution history in the service. **Express** does not provide equivalent execution history in the Step Functions service, so CloudWatch Logs should be configured for more complete execution analysis. CloudWatch Logs delivery for Step Functions is best effort and should not be mistaken for a transactionally guaranteed audit stream. [41]

Step Functions can enable AWS X-Ray tracing, which generates service maps and traces to help isolate delays or failures across service calls. This is an advantage in cross-service tracing compared with monitoring only the status of individual data pipelines. [42]

CloudWatch Composite Alarms combine several metric alarms using Boolean conditions to reduce noise. Depending on the configured action path, alarms can notify SNS, invoke Lambda, or create operational items/incidents through supported AWS integrations. [43]

A recommended AWS alerting baseline includes Glue job failure/timeout, DPU utilization, executor skew, Step Functions `ExecutionsFailed`, `ExecutionsTimedOut`, and `ExecutionThrottled`, EventBridge failed invocations, and dead-letter queue (DLQ) depth. Related alerts should be aggregated into service-health incidents rather than paging independently for every minor task failure. Glue observability metrics and Step Functions CloudWatch metrics support this approach. [39][40]

## Security, Scalability, Cost, and DevOps

### Security and Compliance

Fabric separates control-plane administration from data-plane authorization. Workspace and item permissions determine who may manage an item; OneLake data access controls govern access to data itself and may be refined at folder, table, schema, row, or column levels depending on the workload and security model. Fabric also integrates Microsoft Entra ID, Purview, sensitivity labels, and auditing capabilities. [1][19]

Azure ADF/Synapse more typically uses Azure RBAC, managed identities, Key Vault, and network isolation. Integration Runtime may be Azure-hosted, self-hosted, or Azure-SSIS, offering flexibility for on-premises and private-network access. [24]

AWS commonly relies on IAM roles and policies, KMS, Lake Formation, and CloudTrail. Glue API activity may be captured by CloudTrail, while CloudWatch Logs can use customer-managed KMS keys. [41][44]

For strongly regulated environments, all three architectures should distinguish **data-access/security audit records** from **job-execution telemetry**. Pipeline run logs alone do not constitute a complete access audit trail.

### Scalability and Performance

Fabric's documented Pipeline limits include up to **1,000 pipelines per workspace**, **10,000 concurrent pipeline runs**, **120 activities per pipeline**, **20 schedules per pipeline**, **50-way ForEach parallelism**, and **100 queued runs per pipeline**. Limits can change, and should be rechecked at deployment time. [4]

Job Scheduler also documents limits such as up to 100 active concurrent jobs per item; submissions beyond the limit may fail. A single job may run for up to 24 days. [6]

Fabric's main operational scaling risk is often not the scheduler but **competition for shared Capacity Units (CUs)**. An F64 capacity provides 64 CUs, corresponding to a theoretical baseline of **1,536 CU-hours per day**. The Capacity Metrics App should therefore drive sizing rather than estimating capacity solely from pipeline counts. [14][15]

Azure Data Factory uses a more elastic usage-based orchestration and Integration Runtime model and does not require pre-purchasing one shared analytics compute pool. Copy throughput can scale using DIUs and related Integration Runtime resources. [30]

AWS Glue scales using DPUs, while Step Functions and EventBridge have serverless control planes. Scaling concerns focus on API quotas, workflow concurrency, downstream throttling, and CloudWatch costs rather than contention for one shared Fabric-like capacity pool. [37][45]

### Typical Cost Models

**Microsoft Fabric.** A published Fabric Pipeline orchestration consumption rate is **0.0056 CU-hours for each non-copy activity run**. Copy data movement is metered using execution time and an intelligent-optimization throughput basis, with a published example rate of **1.5 CU-hours per hour of the corresponding copy-throughput resource**. Actual costs depend on CU consumption and the region/capacity commercial arrangement. [13]

Assume 100 daily workloads, each containing 10 non-copy activities and one ten-minute copy operation. With an equivalent copy-throughput resource, the illustrative monthly estimate is:

```text
non-copy:
100 × 30 × 10 × 0.0056 = 168 CU-hours

copy:
100 × 30 × (10/60) × 1.5 ≈ 750 CU-hours

pipeline total ≈ 918 CU-hours/month
```

An illustrative incremental capacity-consumption valuation is therefore:

```text
918 × regional CU-hour unit price
```

This does **not** include compute consumed by Notebooks, Dataflow Gen2, Warehouse, or other items invoked by the pipelines. Those workloads also consume Fabric capacity. Use actual Capacity Metrics App data to validate an estimate against real executions. [13]

Microsoft advertises Fabric capacity reservation savings of roughly 41% compared with pay-as-you-go pricing in applicable scenarios. Spark has an optional Autoscale Billing model, and capacity overage introduces additional billing mechanics. Commercial terms and available configurations should be checked for the target region and date. [15][16]

**Azure Data Factory.** Microsoft pricing examples list Azure Integration Runtime orchestration at approximately **$1 per 1,000 runs** and data movement at **$0.25 per DIU-hour**. The actual rate varies by region and Integration Runtime configuration. [30]

For 30,000 monthly activity runs and 2,000 DIU-hours of copying:

```text
orchestration = 30,000 / 1,000 × $1 = $30
data movement = 2,000 × $0.25 = $500
baseline ADF ≈ $530/month
```

This excludes Mapping Data Flow, Log Analytics ingestion, Azure Monitor alerts, downstream Synapse/Databricks, networking/egress, and other charges. The important point is that ADF is fundamentally charged by activity runs and Integration Runtime execution, while logging and alerting add separate Azure Monitor usage-based costs. [30][31]

**AWS.** An official AWS Glue US-region illustrative rate for standard Spark ETL is **$0.44 per DPU-hour**. For one daily job with six DPUs running for 15 minutes:

```text
6 × 0.25 × $0.44 × 30 = $19.80/month
```

This is equivalent to an illustrative **$0.66 for one execution** using six DPUs for 15 minutes. [45]

Assume Step Functions Standard runs 100 workflows daily, each with 20 state transitions: that yields 60,000 monthly transitions. Using **$0.025 per 1,000 transitions** and the first **4,000 monthly transitions free** as an illustrative assumption:

```text
(60,000 - 4,000) / 1,000 × $0.025 ≈ $1.40/month
```

Retries also generate additional transitions and can increase cost. [46]

EventBridge Scheduler's published Free Tier includes the first **14 million monthly invocations**, making pure scheduling inexpensive for many batch workloads. Beyond that, the published illustration uses **$1 per million invocations**. [47]

In practice, the largest AWS charges in an analytics workflow often come from Glue/EMR/Redshift/S3 and CloudWatch logging rather than modest volumes of EventBridge schedules or Step Functions transitions.

> **Cost-comparison caution:** The scenarios above intentionally preserve the original report's illustrative numbers. They are not normalized end-to-end benchmarks: Fabric CU-hours, ADF DIU-hours/activity counts, and AWS DPUs/state transitions represent different compute and control-plane units. Compare production bills using equivalent workload SLAs, data volumes, and observed execution metrics.

### CI/CD and Infrastructure as Code (IaC)

Fabric's CI/CD capabilities include GitHub/Azure DevOps Git integration, Deployment pipelines, REST APIs, Variable Libraries, Fabric CLI, a Terraform provider, and `fabric-cicd`. Microsoft's guidance discusses Terraform for provisioning Fabric infrastructure as part of a CI/CD practice. [17][18]

Job Scheduler schedules can also take part in item deployment: they are represented in item definitions via `.schedules` files and can be managed by public APIs. [6]

A conceptual Fabric CI/CD lifecycle looks like this:

```yaml
# Conceptual example; not a complete Fabric CLI workflow.
pull_request:
  - validate item definitions
  - validate environment variables

merge_to_main:
  - sync workspace from Git
  - deploy Dev -> Test
  - run smoke pipelines
  - query Monitoring Item for failures
  - deploy Test -> Prod
```

Fabric providers and APIs continue to evolve. Terraform resource schemas should be validated against the official provider version in use rather than copied unchanged into long-lived templates. [17]

Azure ADF/Synapse traditionally uses Git and ARM templates for CI/CD, including automated ADF publishing with Azure Pipelines. Diagnostic settings, alert rules, and other monitoring resources can be deployed using Bicep. [32][33]

The following simplified Azure Bicep monitoring pattern is conceptual and assumes the data factory resource is defined elsewhere:

```bicep
resource la 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'dataops-la'
  location: resourceGroup().location
}

resource diag 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: 'adf-diag'
  scope: dataFactory
  properties: {
    workspaceId: la.id
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
      }
    ]
  }
}
```

Microsoft documents deployment of monitoring resources, diagnostic settings, and alert definitions through Bicep. [33]

AWS commonly deploys Step Functions, Glue, EventBridge, and CloudWatch through CloudFormation, CDK, or Terraform. A simplified EventBridge Scheduler resource looks like this:

```yaml
Resources:
  DailySchedule:
    Type: AWS::Scheduler::Schedule
    Properties:
      ScheduleExpression: "cron(0 2 * * ? *)"
      FlexibleTimeWindow:
        Mode: "OFF"
      Target:
        Arn: !Ref StateMachineArn
        RoleArn: !GetAtt SchedulerRole.Arn
```

EventBridge Scheduler supports cron schedules, fixed-rate schedules, time zones, retry configuration, and at-least-once delivery. The example assumes the referenced state machine and IAM role are defined elsewhere. [48]

## Failure Recovery, Migration, and Implementation Recommendations

### Common Failure Modes

Fabric's most important operational failure modes include capacity throttling; contention with downstream Spark or Warehouse execution; expired or invalid pipeline authentication credentials; transient activity errors; automatic disabling of schedules; and the possibility that Monitoring/Activator itself is affected by capacity pressure. The Job Scheduler documentation describes automatically disabling schedules after repeated consecutive failures, with thresholds varying by item (often around ten failures). [6]

A further consideration is the dependence of Activator and Power BI monitoring experiences on the state of their underlying monitoring database and capacity. During serious capacity throttling, **the capacity producing the incident and the capacity supporting alert generation may interfere with one another**. Some monitoring ingestion and query paths may remain available while Activator-driven notifications are delayed or throttled. [2]

Accordingly, critical Fabric deployments should consider placing centralized Monitoring Items on a separate or more stable capacity rather than sharing all operational visibility with the most burst-prone production workloads.

Azure ADF failure modes include unreachable Integration Runtime infrastructure, source/destination throttling, managed identity or Key Vault authorization errors, Mapping Data Flow cluster startup problems, and pipeline execution SLA overruns. Tumbling Window retry/backfill is valuable in recovering periodic batch processing. [23][24]

AWS failure modes include Lambda/Glue/EMR throttling, Step Functions state timeout, EventBridge target delivery failure, IAM role misconfiguration, and unexpectedly high CloudWatch logging costs. Step Functions Retry/Catch and timeout provide explicit workflow-level recovery primitives. [38]

### Recommended Recovery Pattern

Use the following general design across all three platforms:

![Failure recovery pattern](diagrams/05_failure_recovery.svg)

The most important principle is that **retry must be paired with idempotency**. For operations with side effects, such as INSERT statements, payments, or external API calls, raising the retry count alone is insufficient; use transaction keys, checkpoints, or compensating workflows. Step Functions Standard's workflow-execution semantics help, but downstream services must still be designed for idempotency. [37]

### Migrating from ADF/Synapse to Fabric

The main challenge in migrating ADF to Fabric is not necessarily the Copy activity; it is the **scheduling and operational semantics**. Microsoft describes support for many familiar ADF copy and orchestration patterns, but tumbling windows are only partially matched, and native backfill is missing. Historical reprocessing and window dependency chains therefore need separate migration designs. [4]

<table>
  <thead>
    <tr><th>ADF/Synapse</th><th>Fabric equivalent or migration pattern</th></tr>
  </thead>
  <tbody>
    <tr><td>Pipeline</td><td>Fabric Pipeline</td></tr>
    <tr><td>Execute Pipeline</td><td>Invoke Pipeline</td></tr>
    <tr><td>Schedule Trigger</td><td>Job Scheduler / Pipeline Schedule</td></tr>
    <tr><td>Storage Event Trigger</td><td>Fabric event trigger</td></tr>
    <tr><td>Tumbling Window</td><td>Interval schedule + parameterized window; implement backfill separately</td></tr>
    <tr><td>Mapping Data Flow</td><td>Dataflow Gen2 / Notebook / Spark</td></tr>
    <tr><td>ADLS</td><td>OneLake / Shortcut</td></tr>
    <tr><td>Azure Monitor logs</td><td>Workspace Monitoring / Eventhouse</td></tr>
    <tr><td>Alert Rule</td><td>Activator / Scheduled job failure notification</td></tr>
    <tr><td>ARM CI/CD</td><td>Git + Deployment Pipelines + Terraform/REST</td></tr>
  </tbody>
</table>
Fabric's Invoke Pipeline activity supports cross-workspace invocation and interoperability patterns with ADF/Synapse, providing an incremental migration bridge. [8]

### Migrating from AWS to Fabric

An AWS Glue Job maps reasonably well to Fabric Notebook, Spark Job, or Dataflow Gen2. S3 objects may be copied into, or referenced through supported OneLake shortcuts from, Fabric. Glue Workflows and EventBridge schedules can be redesigned with Fabric Pipelines and Job Scheduler/Real-Time Hub.

The difficult migration cases are long-running Step Functions state machines with callback tokens, complex compensation, and orchestration across dozens of AWS service integrations. Fabric Pipelines are **not a drop-in equivalent to Step Functions state machines**. Step Functions Standard can run for up to one year, while Fabric is oriented more strongly toward analytical jobs and data pipelines. [37]

Therefore, do not rewrite every Step Functions business workflow as a Fabric pipeline merely to consolidate on one cloud data platform. Migrate the components that genuinely belong in the data-engineering and analytics control plane.

### Third-Party Observability

Azure Monitor diagnostics can be exported to Event Hubs or partner systems, making integration with Splunk, Datadog, and other external platforms practical. [25][26]

AWS CloudWatch supports integration with the OpenTelemetry ecosystem and supports several metric/query interfaces alongside traditional CloudWatch metrics. [49]

Fabric's common integration approach is **Workspace Monitoring → Eventhouse/KQL → API/export/integration**, or using adjacent Azure infrastructure to connect Fabric operational events with an existing monitoring stack. Organizations with centralized SIEM/APM should not rely exclusively on Fabric Monitoring hub screens for their operational views.

### Implementation Priorities

For Fabric production workloads, adopt a four-layer approach: **L1 job status; L2 workload performance; L3 capacity and SLA; and L4 incident response**. L1 uses Monitoring hub and scheduled-failure notifications; L2 uses Workspace Monitoring/KQL; L3 uses Capacity Metrics, freshness, and P95 duration; L4 uses Activator and Teams/email, extended to Logic Apps or ITSM/on-call platforms such as PagerDuty where appropriate. Fabric covers many elements of the first three layers, but organization-wide escalation policies, on-call rotations, dynamic anomaly detection, and mature incident management are often better handled with Azure Monitor or a specialized external system. [2][3][10][29]

For Azure, ADF + Azure Monitor remains a relatively low-risk choice when complex window scheduling, Hybrid Integration Runtime, and mature alert governance are required and a unified Fabric SaaS model is not the overriding goal. For AWS, keep Glue focused on data processing, use Step Functions for cross-service DAGs and compensation, and let EventBridge own time- and event-based initiation. Glue Workflow should not be forced to implement every generic business workflow. [24][35][37]

## Roadmap, Limitations, and Final Recommendations

Fabric's most strategically important direction is not simply another Pipeline activity. It is the convergence of **Workspace Monitoring, Monitoring hub, Activator, Operations Agent, and unified CI/CD**. Microsoft's documentation positions Workspace Monitoring as a major operational observability entry point and describes Monitoring Items alongside Eventhouse, Activator, and emerging operational intelligence capabilities. Fabric is increasingly treating platform telemetry itself as a queryable data product. [2]

However, as of November 2026, several constraints should be treated as architectural concerns rather than minor feature gaps: Workspace Monitoring and certain job alert features are still in preview; each workspace can have only one active telemetry collection arrangement under the documented model; monitoring targets must satisfy regional requirements; retention defaults to 30 days; the monitoring database is read-only; Fabric Pipeline does not fully support tumbling-window backfill; pipelines have limits such as 120 activities and 20 schedules; and capacity contention can affect both business execution and portions of the alerting path. [2][3][4]

If the primary goal is a **unified lakehouse, Power BI, data engineering, real-time analytics, and operations experience**, Fabric generally introduces the least architectural assembly overhead. If the core requirement is **complex scheduling dependencies, hybrid networking, and strict SLA operations**, Azure Data Factory/Synapse plus Azure Monitor remains more mature. If the requirement is **high-throughput serverless event orchestration, durable long-running workflows, and state machines spanning many services**, AWS Step Functions plus EventBridge offers the stronger workflow abstraction. [1][23][27][37]

For most Microsoft-centric enterprises, the most practical target architecture is **not Fabric versus Azure as an exclusive choice**. Instead, it is **Fabric as the data-platform orchestration/control plane and Azure Monitor, Logic Apps, and enterprise ITSM as the cross-platform operations control plane**. This retains Fabric's unified management of OneLake, Pipeline, Warehouse, Spark, and Power BI while leveraging Azure Monitor's dynamic thresholds, Action Groups, longer-term diagnostics, and external incident-management integrations. [1][27][29]

### References

All source URLs are consolidated here rather than embedded in the report body. References are grouped by platform and numbered to match the citations in the text. These are primarily official vendor documentation and pricing pages; preview status, limits, and pricing should be checked again at implementation time.

**Microsoft Fabric — architecture, pipelines, scheduling, observability, security, and pricing**

[1] Microsoft Learn — *What is Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/fundamentals/microsoft-fabric-overview

[2] Microsoft Learn — *Workspace Monitoring Overview*.  
https://learn.microsoft.com/en-us/fabric/fundamentals/workspace-monitoring-overview

[3] Microsoft Learn — *Set up job alerts in the Monitor hub (preview)*.  
https://learn.microsoft.com/en-us/fabric/admin/monitoring-hub-alerts

[4] Microsoft Learn — *Data Factory limitations overview*.  
https://learn.microsoft.com/en-us/fabric/data-factory/data-factory-limitations

[5] Microsoft Learn — *Run, schedule, or use events to trigger a pipeline*.  
https://learn.microsoft.com/en-us/fabric/data-factory/pipeline-runs

[6] Microsoft Learn — *Job Scheduler in Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/fundamentals/job-scheduler

[7] Microsoft Learn — *Activity overview*.  
https://learn.microsoft.com/en-us/fabric/data-factory/activity-overview

[8] Microsoft Learn — *Invoke pipeline activity*.  
https://learn.microsoft.com/en-us/fabric/data-factory/invoke-pipeline-activity

[9] Microsoft Learn — *Activity Retries in Microsoft Fabric Data Factory*.  
https://learn.microsoft.com/en-us/fabric/data-factory/activity-retries

[10] Microsoft Learn — *Choose How to Monitor Pipeline Runs*.  
https://learn.microsoft.com/en-us/fabric/data-factory/monitor-data-factory

[11] Microsoft Learn — *Create Alerts for Pipeline Runs*.  
https://learn.microsoft.com/en-us/fabric/data-factory/create-alerts-for-pipeline-runs

[12] Microsoft Learn — *Enable Workspace Monitoring (Preview) in Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/data-factory/workspace-monitoring

[13] Microsoft Learn — *Pricing for Pipelines*.  
https://learn.microsoft.com/en-us/fabric/data-factory/pricing-pipelines

[14] Microsoft Learn — *Plan your capacity size*.  
https://learn.microsoft.com/en-us/fabric/enterprise/plan-capacity

[15] Microsoft Learn — *Capacity overage in Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/enterprise/capacity-overage-overview

[16] Microsoft Azure — *Microsoft Fabric pricing*.  
https://azure.microsoft.com/en-us/pricing/details/microsoft-fabric/

[17] Microsoft Learn — *Introduction to CI/CD in Microsoft Fabric*.  
https://learn.microsoft.com/en-us/fabric/cicd/cicd-overview

[18] Microsoft Learn — *Plan CI/CD for Microsoft Fabric Solutions*.  
https://learn.microsoft.com/en-us/fabric/fundamentals/understand-best-practices-fabric-cicd

[19] Microsoft Learn — *Data security overview*.  
https://learn.microsoft.com/en-us/fabric/onelake/get-started-security

[20] Microsoft Learn — *Explore Job events in Fabric Real-Time hub*.  
https://learn.microsoft.com/en-us/fabric/real-time-hub/explore-fabric-job-events

[21] Microsoft Learn — *Run an Apache Spark job definition*.  
https://learn.microsoft.com/en-us/fabric/data-engineering/run-spark-job-definition

**Microsoft Azure — Data Factory, Azure Monitor, CI/CD, and pricing**

[22] Microsoft Learn — *Pipeline execution and triggers in ADF/Synapse*.  
https://learn.microsoft.com/en-us/azure/data-factory/concepts-pipeline-execution-triggers

[23] Microsoft Learn — *Create tumbling window triggers*.  
https://learn.microsoft.com/en-us/azure/data-factory/how-to-create-tumbling-window-trigger

[24] Microsoft Learn — *Integration Runtime in ADF/Synapse*.  
https://learn.microsoft.com/en-us/azure/data-factory/concepts-integration-runtime

[25] Microsoft Learn — *Monitor Azure Data Factory*.  
https://learn.microsoft.com/en-us/azure/data-factory/monitor-data-factory

[26] Microsoft Learn — *Configure diagnostic settings and a workspace*.  
https://learn.microsoft.com/en-us/azure/data-factory/monitor-configure-diagnostics

[27] Microsoft Learn — *Types of Azure Monitor alerts*.  
https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-types

[28] Microsoft Learn — *Dynamic thresholds for Azure Monitor alert rules*.  
https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-dynamic-thresholds

[29] Microsoft Learn — *Create and manage Action Groups in Azure Monitor*.  
https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/action-groups

[30] Microsoft Azure — *Azure Data Factory data pipeline pricing*.  
https://azure.microsoft.com/en-us/pricing/details/data-factory/data-pipeline/

[31] Microsoft Azure — *Azure Monitor pricing*.  
https://azure.microsoft.com/en-us/pricing/details/monitor/

[32] Microsoft Learn — *Automated publishing for ADF continuous integration and delivery*.  
https://learn.microsoft.com/en-us/azure/data-factory/continuous-integration-delivery-improvements

[33] Microsoft Learn — *Create monitoring resources using Bicep*.  
https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/scenarios-monitoring

[34] Microsoft Learn — *Operationalize data pipelines*.  
https://learn.microsoft.com/en-us/azure/data-factory/tutorial-operationalize-pipelines

**Amazon Web Services — Glue, Step Functions, EventBridge, CloudWatch, and pricing**

[35] AWS Documentation — *Overview of workflows in AWS Glue*.  
https://docs.aws.amazon.com/glue/latest/dg/workflows_overview.html

[36] AWS Documentation — *Automating AWS Glue with EventBridge*.  
https://docs.aws.amazon.com/glue/latest/dg/automating-awsglue-with-cloudwatch-events.html

[37] AWS Documentation — *Choosing workflow type in AWS Step Functions*.  
https://docs.aws.amazon.com/step-functions/latest/dg/choosing-workflow-type.html

[38] AWS Documentation — *Configure error handling in Step Functions*.  
https://docs.aws.amazon.com/step-functions/latest/dg/workflow-studio-process-error.html

[39] AWS Documentation — *Monitoring AWS Glue with Amazon CloudWatch*.  
https://docs.aws.amazon.com/glue/latest/dg/monitor-cloudwatch.html

[40] AWS Documentation — *Monitoring Step Functions metrics with CloudWatch*.  
https://docs.aws.amazon.com/step-functions/latest/dg/procedure-cw-metrics.html

[41] AWS Documentation — *Using CloudWatch Logs to log Step Functions execution history*.  
https://docs.aws.amazon.com/step-functions/latest/dg/cw-logs.html

[42] AWS Documentation — *Trace Step Functions with AWS X-Ray*.  
https://docs.aws.amazon.com/step-functions/latest/dg/concepts-xray-tracing.html

[43] AWS Documentation — *Composite alarms in Amazon CloudWatch*.  
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/alarm-combining.html

[44] AWS Documentation — *Logging and monitoring in AWS Glue*.  
https://docs.aws.amazon.com/glue/latest/dg/logging-and-monitoring.html

[45] AWS — *AWS Glue pricing*.  
https://aws.amazon.com/glue/pricing/

[46] AWS — *AWS Step Functions pricing*.  
https://aws.amazon.com/step-functions/pricing/

[47] AWS — *Amazon EventBridge pricing*.  
https://aws.amazon.com/eventbridge/pricing/

[48] AWS — *Amazon EventBridge FAQs*.  
https://aws.amazon.com/eventbridge/faqs/

[49] AWS Documentation — *Metrics in Amazon CloudWatch*.  
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/working_with_metrics.html
